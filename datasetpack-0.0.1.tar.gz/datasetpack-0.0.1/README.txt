Quick Start Guide
-----------------

This is supposed to be a readme file of the datasetpack I have developed in the subject.